from flask import Flask
from flask import url_for, request, render_template

app = Flask(__name__)


@app.route('/form_sample', methods=['POST', 'GET'])
def form_sample():
    if request.method == 'GET':
        return render_template('test.html')
    elif request.method == 'POST':
        print(request.form['email'])
        print(request.form['name'])
        print(request.form['surname'])
        print(request.form['education'])
        print(request.form['file'])
        print(request.form['prof'])
        print(request.form['about'])
        print(request.form['accept'])
        print(request.form['sex'])
        return "Форма отправлена"


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
